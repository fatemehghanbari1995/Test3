
    public class Student{

        public int Id;
        public String Name;
        public String Email;

        public int getId() {
            return Id;
        }

        public void setId(int id) {
            Id = id;
        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }

        public String getFamily() {
            return Email;
        }

        public void setFamily(String family) {
            this.Email = family;
        }


        public static class User{

            User user= new User();

            public void setid(int i) {
            }

            public void setName(String maki) {
            }

            public void setEmail(String s) {
            }
        }





}



