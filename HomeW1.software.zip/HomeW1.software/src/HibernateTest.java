import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.lang.module.Configuration;


public class HibernateTest {

    public static void Main(String[] args){

        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();
        session.beginTransaction();
        Student.User user = new Student.User();
        user.setid(120);
        user.setName("maki");
        user.setEmail("@www.yuhgs.com");
        session.save(user);
        session.getTransaction().commit();
    }
}
